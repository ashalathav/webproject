<?php
include "db.php";



if($_SERVER["REQUEST_METHOD"] == "POST" && $_POST['userEmail']!='' && $_POST['userPassword']!=''){
	$email = mysqli_real_escape_string($con,$_POST['userEmail']);
	$password = mysqli_real_escape_string($con,$_POST['userPassword']);
	$sql = "SELECT * FROM user_info WHERE email = '$email' AND password = '$password'";
	$run_query = mysqli_query($con,$sql);
	$row = mysqli_fetch_assoc($run_query);
	if($password == $row["password"])
	{    
	    session_start();
		echo "<script type='text/javascript'>alert('login successfull');</script>";exit;
		echo json_decode(1);exit;
	}
	else{
			echo json_decode(0);exit;
		}
}

?>