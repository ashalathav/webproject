$(document).ready(function(){
	/* handling form validation */
	$("#login-form").validate({
		rules: {
			password: {
				required: true,
			},
			email: {
				required: true,
			},
		},
		messages: {
			password:{
			  required: "Please enter your password"
			 },
			email: "Please enter your email",
		},
		submitHandler: submitForm	
	});	

	/* Handling login functionality */
	function submitForm() {		
		var data = $("#login-form").serialize();
		var email = $("#email").val();
        var pass = $("#password").val();
		$.ajax({				
			type : 'POST',
			url  : 'handler.php?action=login',
			data : {login:1,userEmail:email,userPassword:pass},
			success : function(data){			
				if(data=="1"){
					$("#login-submit").html('Signing In ...');
					alert('login successfull');
					setTimeout(' window.location.href = "profile.php"; ',1000);
				} else if(data=="0") {
                    alert('invalid');
				}
			},
			error : function(data){
				alert('invalid credantials');
			}
		});
		return false;
	}
	
	function logout() {
		$.ajax({				
			type : 'POST',
			url  : 'handler.php?action=logout',
			data : data,
			success : function(response){
				window.location.href = "customer_login.php";
			}
		});
		return false;
	}   
});