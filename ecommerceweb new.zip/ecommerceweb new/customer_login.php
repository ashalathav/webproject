<!DOCTYPE html>
<html>
<head>

		<meta charset="UTF-8">
		<title>Online Store</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.0.3.js"></script>
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
		<style>
		.f {
		  margin-right:450px;
		  margin-top:20px;
		  margin-left:450px;
		  margin-bottom:20px;
		  }
		  h2 {
		  text-align:center;
		  }
		</style>
</head>
<body>
<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="#" class="navbar-brand">Online Store</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Logout</a></li>
			</ul>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<h2> LOGIN FORM </h2>
<form id="login-form" name="login_form" role="form" class="f" method="post">
		<label for="email">Email</label>
		<input type="email" class="form-control" name="email" id="email"/>
		<label for="email">Password</label>
		<input type="password" class="form-control" name="password" id="password"/>
		<p><br/></p>
									
        <button type="submit" name="login-submit" id="login-submit" class="btn btn-primary btn-block btn-flat">SIGN IN</button>
</form>
<div class="panel-footer">&copy; 2019</div>
<script type="text/javascript" src="loginF.js"></script>
</body>
</html>