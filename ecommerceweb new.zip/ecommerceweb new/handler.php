<?php
//include connection file 
include_once("connection.php");
$db = new dbObj();
$connString =  $db->getConnstring();

$params = $_REQUEST;
$action = $params['action'] !='' ? $params['action'] : '';
$stdCls = new Student($connString);

switch($action) {
 case 'login':
	$stdCls->login();
 break;
 case 'logout':
	$stdCls->logout();
 break;
  case 'changePassword':
	$stdCls->changePassword();
 break;
 default:
 return;
}
class Student {
	protected $conn;
	protected $data = array();
	function __construct($connString) {
		$this->conn = $connString;
	}
	
	function login() {
		if(isset($_POST['login'])) {
			$user_email = trim($_POST['userEmail']);
			$user_password = trim($_POST['userPassword']);
			$sql = "SELECT * FROM user_info WHERE email ='$user_email'";
			$resultset = mysqli_query($this->conn, $sql) or die("database error:". mysqli_error($this->conn));
			$row = mysqli_fetch_assoc($resultset);
			if($user_password == $row['password']){
			    $_SESSION['user_email']=$row['email'];
				 $_SESSION['user_id']=$row['user_id'];
				echo json_decode(1);
			} else {
				echo json_decode(0); // wrong details
			}
		}
	}
	function logout() {
		unset($_SESSION['user_email']);
		if(session_destroy()) {
			header("Location: customer_login.php");
		}
	}
	
	function changePassword()
	{
		$user_email = $_SESSION['user_email'];
		echo $user_email;
		$con_pass = $_POST['confirmPassword'];
		$pass = "SELECT password FROM user_info WHERE email = '$user_email'";
		$result = mysqli_query($this->conn, $pass) or  die("database error:". mysqli_error($this->conn));
		$row = mysqli_fetch_assoc($result);
		$exist_pass = $row['password'];
		if($exist_pass == $_POST['existPassword'] && $_POST['newPassword'] == $_POST['confirmPassword'])
		{
			$update_sql = "UPDATE user_info SET password = '$con_pass' WHERE email = '$user_email' ";
			$updateset = mysqli_query($this->conn, $update_sql) or die("database error:". mysqli_error($this->conn));
			$updated_sql = "select password from user_info where email = '$user_email'";
			$result_set = mysqli_query($this->conn, $updated_sql) or die("database error:". mysqli_error($this->conn));
			$updated_row = mysqli_fetch_array($result_set);
			$pass = $updated_row['password'];
			if($con_pass == $pass){
				echo '1';
			}else{
				echo '0';
			}
			}else{
				 echo '0';
			}
	}
}
?>