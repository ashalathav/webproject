 <!DOCTYPE html>
 <html>
	<head>
		<meta charset="UTF-8">
		<title>Online Store</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<style>
			#b1
			{	
				margin-top:80px;
				margin-left:440px;
				margin-right:120px;
			}
		</style>
	</head>
 <body id="b1">
 <div class="content-wrapper">
      <section class="content-header">
        <h1>
          Change Password
        </h1>
      </section>
      <section class="content">
        <div class="row">
          <div class="col-md-6">
            <div hidden id="changed" class="alert alert-success alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-check"></i> Alert!</h4>
              Password changed, you'll be redirected to Login Page in 3 seconds.
            </div>
            <div hidden id="error" class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-warning"></i> Alert!</h4>
              Error Changing Password!
            </div>
            <div hidden id="passMismatch" class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-warning"></i> Alert!</h4>
              Passwords don't Match!
            </div>
			<div class="box box-primary">
              <form role="form" id="changePasswordF" method="post">
                <div class="box-body">
                  <div class="form-group">
                    <label for="existPassword">Existing Password</label>
                    <input type="password" class="form-control" id="existPassword" name="existPassword" placeholder="Existing Password">
                  </div>
                  <div class="form-group">
                    <label for="newPassword">New Password</label>
                    <input type="password" class="form-control" id="newPassword" name="newPassword" placeholder="New Password">
                  </div>
                  <div class="form-group">
                    <label for="confirmPassword">Re-type New Password</label>
                    <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirm New Password">
                  </div>
                </div>
                <div class="box-footer">
                  <button type="submit" class="btn btn-primary">SUBMIT</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
		<script src="changePassword.js"></script>
	</body>
	</html>