$("form#changePasswordF").submit(function(){
	$("#changed").hide();
	$("#error").hide();
	$("#passMismatch").hide();
    var formData = new FormData($(this)[0]);
    var path = "handler.php?action=changePassword";
    var newP = $("#newPassword").val();
    var confirmP = $("#confirmPassword").val();
    if(newP==confirmP)
    {
        $.ajax({
            url: path,
            type: 'POST',
            data: formData,
            success: function (data) {
                if(data=1)
                {
                    $("#changePasswordF").hide();
                    $("#changed").show();
                    window.setTimeout(function(){window.location.href = "handler.php?action=logout";}, 2500);
                }
                if(data==0)
                {
                    $("#error").show();
                }
            },
            error: function(data){
                $("#changed").hide();
                $("#error").show();
            },
            cache: false,
            contentType: false,
            processData: false
        });
    }
    else
    {
      $("#passMismatch").show();
  }
  return false;
});